<?php namespace App\Models;
use CodeIgniter\Model;
class KbArticlesModel extends Model {
  protected $table='kb_articles'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
