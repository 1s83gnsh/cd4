<?php namespace App\Models;
use CodeIgniter\Model;
class TestQuestionsModel extends Model {
  protected $table='test_questions'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
