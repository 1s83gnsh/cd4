<?php namespace App\Models;
use CodeIgniter\Model;
class TestsModel extends Model {
  protected $table='tests'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
