<?php namespace App\Models;
use CodeIgniter\Model;
class TestAnswersModel extends Model {
  protected $table='test_answers'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
