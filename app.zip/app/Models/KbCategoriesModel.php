<?php namespace App\Models;
use CodeIgniter\Model;
class KbCategoriesModel extends Model {
  protected $table='kb_categories'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
