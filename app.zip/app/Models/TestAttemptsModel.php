<?php namespace App\Models;
use CodeIgniter\Model;
class TestAttemptsModel extends Model {
  protected $table='test_attempts'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
