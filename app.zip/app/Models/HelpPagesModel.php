<?php namespace App\Models;
use CodeIgniter\Model;
class HelpPagesModel extends Model {
  protected $table='help_pages'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
