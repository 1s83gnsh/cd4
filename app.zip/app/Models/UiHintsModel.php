<?php namespace App\Models;
use CodeIgniter\Model;
class UiHintsModel extends Model {
  protected $table='ui_hints'; protected $primaryKey='id'; protected $returnType='array'; protected $allowedFields=['*']; }
